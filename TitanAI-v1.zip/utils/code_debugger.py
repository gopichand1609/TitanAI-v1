def explain_code(code):
    if not code.strip():
        return "Please enter some code."
    return "This code looks fine. (In real app, OpenAI API explains here.)"