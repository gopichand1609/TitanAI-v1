def translate_text(text, target_lang):
    return f"Translated '{text}' to [{target_lang}] (mock result)."