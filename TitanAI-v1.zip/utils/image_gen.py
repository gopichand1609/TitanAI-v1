def generate_image(prompt):
    return "https://via.placeholder.com/300x200.png?text=" + prompt.replace(" ", "+")