def extract_text_from_image(file):
    return "Sample extracted text from image."