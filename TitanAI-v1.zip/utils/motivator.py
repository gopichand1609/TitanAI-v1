def get_motivational_quote():
    return "Believe in yourself. You're capable of amazing things!"