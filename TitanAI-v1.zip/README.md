# TitanAI v1
An AI-powered assistant with image generation, code debugging, OCR, translation, and motivational quotes.